<?php 
include('conexion/conexion.php');
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');
if(($_GET['secure']==null) OR (strlen($_GET['secure'])>24) OR (strlen($_GET['secure'])<24)){
header('Location: index.php');
} 
?>

<?php include('assets/head.php'); ?>
<body>
  <?php include('assets/menu.php'); ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Certificados</h1>
          </div>
           <div style="margin-top: 10px; margin-bottom: 10px;" class="col-lg-6">
              <a class="btn btn-primary" href="certificados.php">Añadir</a>
            </div>

          <form method="POST" action="Acciones/guardar.php" class="form-horizontal" enctype="multipart/form-data">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Nombre</label>
                <div class="col-lg-10">
                  <input type="text" name="nombre" class="form-control" id="inputEmail" placeholder="Nombre del certificado" required="required">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Archivo</label>
                <div class="col-lg-10">
                  <input type="file" name="archivo" class="form-control" id="inputEmail" placeholder="Archivo" required="required">
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancelar</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>  
          <table class="display nowrap dataTable dtr-inline" id="myTable" style="width:100%;"> 
          <thead>
            <tr>
              <td class="titulo">Nombre</td>
              <td class="titulo">Archivo</td>
              <td class="titulo">Eliminar</td>
            </tr>
          </thead>
          <tbody>
        <?php
          $result=mysqli_query($con, "SELECT * FROM archivos");
          $i=1;
          while ($row = mysqli_fetch_array($result)){
            echo "
              <tr>
                <td> ".$row['nombre']."</td>
                <td><a href='files/".$row['archivo']."'><img src='images/zip.png'></img></a></td>
                <td><a href='acciones/eliminar.php?id=".$row['id']."'>Eliminar</a></td>
              </tr>";
            $i++;
          }
        ?>
          </tbody>
          </table>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

