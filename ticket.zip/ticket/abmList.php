<?php 
include('conexion/conexion.php');
$getClientes = mysqli_query($con, "SELECT * FROM abm");
error_reporting(0);
//obtener hora/fecha actual
$rel= $_GET['rel'];
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');
function make_links($text, $class='', $target='_blank'){
    return preg_replace('!((http\:\/\/|ftp\:\/\/|https\:\/\/)|www\.)([-a-zA-Zа-яА-Я0-9\~\!\@\#\$\%\^\&\*\(\)_\-\=\+\\\/\?\.\:\;\'\,]*)?!ism', 
    '<a class="'.$class.'" href="//$3" target="'.$target.'">$1$3</a>', 
    $text);
}
?>

<?php include('assets/head.php'); ?>
<body>
  <?php include('assets/menu.php'); ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Listado</h1>
          </div>
           <div style="margin-top: 10px; margin-bottom: 10px;" class="col-lg-6">
              <a class="btn btn-primary" href="abm.php">Añadir</a>
            </div>
          <table class="display nowrap dataTable dtr-inline" id="myTable" style="width:100%;"> 
          <thead>
            <tr>
              <td class="titulo">Título</td>
              <td class="titulo">DTR</td>
              <td class="titulo">Enlace</td>
              <td class="titulo">Opciones</td>
            </tr>
          </thead>
          <tbody>
        <?php
          $result=mysqli_query($con, "SELECT * FROM abm WHERE tipo='$rel'");
          $i=1;
          while ($row = mysqli_fetch_array($result)){
            echo "
              <tr>
                <td> ".$row['titulo']."</td>
                <td><a href='".$row['enlace']."'>".$row['dtr']."</a></td>
                <td>".make_links($row['enlace'])."</td>
                <td><a href='abmEdit.php?id=".$row['id']."'>Editar</a></td>
              </tr>";
            $i++;
          }
        ?>
          </tbody>
          </table>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

