<?php 
include('conexion/conexion.php');
mysqli_query($con, "SET NAMES 'utf8'");
header("Content-Type: text/html;charset=utf-8");
$getClientes = mysqli_query($con, "SELECT * FROM clientes");
?>
<?php include('assets/head.php'); ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Buscar</h1>
          </div>
          <form method="POST" action="busqueda.php" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Número de ticket</label>
                <div class="col-lg-9">
                  <input type="text" name="ticket" class="form-control" id="inputEmail" placeholder="Número de ticket" >
                </div>
                <input type="checkbox" class="col-lg-1" name="opciones[]" value="ticket" /></td>
              </div>

              <div class="form-group">
                <label class="col-lg-2 control-label">Cliente</label>
                <div class="col-lg-9">
                <?php  
                  echo "<select id='cliente' name='cliente' class='form-control'>";
                  echo "<option value='' selected='selected'>- Selecciona -</option>";
                  while ($row = mysqli_fetch_array($getClientes)) {
                      echo "<option value='" . $row['nom_cliente']. "'>" . $row['nom_cliente']. "</option>";
                  }
                  echo "</select><br>";
                ?>
              </div>
                <input type="checkbox" class="col-lg-1" name="opciones[]" value="cliente" /></td>
              </div>

              <div class="form-group">
                <label for="textArea" class="col-lg-2 control-label">Turno</label>
                <div class="col-lg-9">
                  <select name="turno"  class='form-control' >
                    <option value="" selected="selected">- Selecciona -</option>
                    <option value="Mañana">Mañana</option>
                    <option value="Tarde">Tarde</option>
                    <option value="Noche">Noche</option>
                  </select>
                </div>
               <input type="checkbox" class="col-lg-1" name="opciones[]" value="turno" /></td>
              </div>
              <div class='form-group' id='datetimepicker2'>
                    <label for="textArea" class="col-lg-2 control-label">Fecha</label>
                  <div class="col-lg-9">
                    <input type='text' name="fecha_sm" id="datepicker" class="datefield form-control" />
                </div>
                <input type="checkbox" class="col-lg-1" name="opciones[]" value="fecha_sm" />
              </div>
              <div class="form-group">
                <div class="col-lg-9 col-lg-offset-3">
                  <button type="reset" class="btn btn-default">Cancel</button>
                  <?php $url='busqueda.php'; ?> 
                  <button type="submit" class="btn btn-primary" onclick="document.location='<?php echo $url; ?>'" value="buscar">Buscar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>