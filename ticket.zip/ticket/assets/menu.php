    <div class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <a href="index.php"><img style="width: 170px;height: 70px;" src="images/cellnex.jpg"></a>
          <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="navbar-collapse collapse" id="navbar-main">
          <ul class="nav navbar-nav">

          <li class="dropdown">
          <a href="index.php" id="themes" style="font-size:15px;" aria-expanded="false"><i class="fa fa-home" aria-hidden="true"></i></a>
          </li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes" aria-expanded="false">Internet Media <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="themes">
                <li><a href="abmList.php?rel=Internet">Documentación</a></li>
                <li class="divider"></li>
                <li class="dropdown-submenu">
                <a class="test" tabindex="-1" href="#">Accesos internet media <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a tabindex="-1" href="https://mediaportal.level3.com/ui/login">Level 3</a></li>
                    <li><a tabindex="-1" href="https://mediaconsole.flumotion.com/accounts/login/?next=/">Flumotion</a></li>
                    <li><a tabindex="-1" href="http://livecdn.cires21.com/account/signin?return_url=%2Fdashboard">Cires 21</a></li>
                    <li><a tabindex="-1" href="https://signin.brightcove.com/login?redirect=https%3A%2F%2Fvideocloud%2Ebrightcove%2Ecom%2">Brightcove</a></li>
                    <li><a tabindex="-1" href="https://control.akamai.com/apps/auth/?TARGET_URL=Y29udHJvbC5ha2FtYWkuY29tL2hvbWVuZy92aWV3L21haW4=#/login">Akamai</a></li>
                    <li><a tabindex="-1" href="https://services.nagra.com/eservice_ent_enu/start.swe?SWECmd=Start&SWEHo=services.nagra.com">Nagra CRM</a></li>
                    </ul>
                    </li>
                    </ul>
                </li>

              <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes" aria-expanded="false">Smart Cities <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="themes">
                <li><a href="abmList.php?rel=Smart">Documentación</a></li>
                <li class="divider"></li>
                <li class="divider"></li>
                <li class="dropdown-submenu">
                <a class="test" tabindex="-1" href="#">Accesos Smart Cities <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a tabindex="-1" href="http://10.1.25.15/zabbix/">Zabbix</a></li>
                    </ul>
                    </li>
                    </ul>
                </li>

               
              <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes" aria-expanded="false">General <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="themes">
                <li><a href="abmList.php?rel=General">Documentación</a></li>
                <li class="divider"></li>
                <li class="divider"></li>
                <li class="dropdown-submenu">
                <a class="test" tabindex="-1" href="#">Accesos General <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a tabindex="-1" href="https://10.1.24.185/nagiosxi/">Nagiosxi</a></li>
                    <li><a tabindex="-1" href="http://itsm-aire-p00:8080/arsys/shared/login.jsp?/arsys/">Aire</a></li>
                    <li><a tabindex="-1" href="http://isis/webtier-9.20/ess.do">Isis</a></li>
                    </ul>
                    </li>
                    </ul>
                </li>


            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes" aria-expanded="false">Tickets <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="themes">
                <li><a href="buscar.php">Buscar</a></li>
                <li class="divider"></li>
                <li><a href="tickets.php">Añadir</a></li>
                <li class="divider"></li>
                <li><a href="index.php">Listado</a></li>
                <li class="divider"></li>
                <li><a href="historicTicket.php">Historico</a></li>
              </ul>
            </li>

             <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes" aria-expanded="false">Clientes <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="themes">
                <li><a href="clientes.php">Añadir</a></li>
                <li class="divider"></li>
                <li><a href="clientesList.php">Listado</a></li>
              </ul>
            </li>

            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes" aria-expanded="false">Información relevante <span class="caret"></span></a>
              <ul class="dropdown-menu" aria-labelledby="themes">
                <li><a href="inforelList.php?rel=Internet">Internet Media</a></li>
                <li><a href="inforelList.php?rel=Smart">Smart Cities</a></li>
                <li><a href="inforelList.php?rel=General">General</a></li>
              </ul>
            </li>

              <li class="dropdown">
          <a href="secure.php" aria-expanded="false">Certificados</a>
          </li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="themes" aria-expanded="false">Macros</a>
            </li>
          </ul>


          <ul class="nav navbar-nav navbar-right">
          <li></li>
          <li></li>
          <li><a href="/"><img style="width: 40px;" src="images/cloud.png"></a></li>
          </ul>
        </div>
      </div>
    </div>
