<?php
  
    header('Content-type: application/json; charset=UTF-8');
    include('../conexion/conexion.php');
     if(isset($_POST['id'])) {
        $id = $_POST['id'];
        $query = mysqli_query($con, "SELECT * FROM novedad WHERE id_novedad=$id");
        $row = mysqli_fetch_assoc($query) ;  
        echo json_encode($row);
         exit; 
     }


     ?>