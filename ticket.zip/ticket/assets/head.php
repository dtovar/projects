
<head>
    <meta charset="utf-8">
    <title>Cellnex</title>
    <meta http-equiv="content-language" content="es">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css" media="screen">
    <link rel="stylesheet" href="css/font-awesome.min.css" media="screen">
    <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/style.css">
        <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>   
      <script>
    $(document).ready(function(){
      $('.dropdown-submenu a.test').on("click", function(e){
        $(this).next('ul').toggle();
        e.stopPropagation();
        e.preventDefault();
      });
    });
  </script>
    <script type="text/javascript">
      $(document).ready(function(){
      $('#myTable').DataTable();
      });
    </script>
    <script>
      $( function() {
        $( "#datepicker, #datepicker2" ).datepicker({dateFormat: "yy-mm-dd"});
      });
    </script>
    <script type="text/javascript">
    $(document).ready(function(){
 
 $(document).on('click', '#getNov', function(e){
  
  e.preventDefault();
  
  var uid = $(this).data('id'); // get id of clicked row
  
  $('#dynamic-content').hide(); // hide dive for loader
  $('#modal-loader').show();  // load ajax loader
  
  $.ajax({
      url: 'assets/getnov.php',
      type: 'POST',
      data: 'id='+uid,
      dataType: 'json'
  })
  .done(function(data){
      console.log(data);
      $('#dynamic-content').hide(); // hide dynamic div
      $('#dynamic-content').show(); // show dynamic div
      $('#titulo_novedad').html(data.titulo_novedad);
      $('#cuerpo_novedad').html(data.cuerpo_novedad);
      $('#modal-loader').hide();    // hide ajax loader
  })
  .fail(function(){
      $('.modal-body').html('<i class="glyphicon glyphicon-info-sign"></i> Something went wrong, Please try again...');
  });
  
 });
 
});  
    </script>
    <style type="text/css">
      /*
       *  STYLE 4
       */
     /* #style-4::-webkit-scrollbar-track
      {
        -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
        background-color: #F5F5F5;
      }

      #style-4::-webkit-scrollbar
      {
        width: 10px;
        background-color: #F5F5F5;
      }

      #style-4::-webkit-scrollbar-thumb
      {
        background-color: #000000;
        border: 2px solid #555555;
      }*/

      @media (min-width: 1200px){
      .col-lg-2.note{
          width: 15.66666667% !important;
      }
    }

    button, submit { 
    border:none;
    background-color: transparent;
    outline: none;
   } 

.new-nav-line{
  margin-top:20px;
}
    </style>
</head>