<?php 
include('conexion/conexion.php');
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');
//get id
if (isset($_GET['id'])) {
$id_rel = $_GET['id'];
$getContenido= mysqli_query($con, "SELECT * FROM inforel WHERE id_rel='$id_rel'");
$fila = mysqli_fetch_array($getContenido);
$titulo_rel = $fila['titulo_rel'];
$cuerpo_rel = $fila['cuerpo_rel'];
$tipo_rel = $fila['tipo_rel'];
}
  $id_rel = $_GET['id'];

if(isset($_POST['Guardar'])){
$titulo_rel = $_POST['titulo_rel'];
$cuerpo_rel = $_POST['cuerpo_rel'];
$tipo_rel = $_POST['tipo_rel'];
$res = mysqli_query($con, "UPDATE inforel SET titulo_rel='$titulo_rel', cuerpo_rel='$cuerpo_rel', tipo_rel='$tipo_rel' WHERE id_rel='$id_rel'");
}
?>

<?php include('assets/head.php'); ?>

<body>

<?php include('assets/menu.php'); ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Añadir Novedad</h1>
          </div>
          <?php 
          if(isset($nameErr)){ echo $nameErr; }
          if($res){
           echo "<p style='color:green;font-size:13px;'> Datos guardados correctamente.</p>";
          }?>
          <form method="POST" action="" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Título de novedad</label>
                <div class="col-lg-10">
                  <input type="text" name="titulo_rel" class="form-control" id="inputEmail" placeholder="Nombre del cliente" value="<?php if(isset($titulo_rel)) { echo $titulo_rel; } ?>" required="required">
                </div>
              </div>
               <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Tipo de novedad</label>
                <div class="col-lg-10">
                  <select name="tipo_rel" class="form-control" required="required">
                    <option value="" selected="selected">- Selecciona -</option>
                    <option value="Internet" <?php if($tipo_rel=="Internet") echo 'selected="selected"';?>>Internet Media</option>
                    <option value="Smart" <?php if($tipo_rel=="Smart") echo 'selected="selected"';?>>Smart</option>
                    <option value="General" <?php if($tipo_rel=="General") echo 'selected="selected"';?>>General</option>

                  </select>
                </div>
              </div>
               <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Cuerpo de novedad</label>
                <div class="col-lg-10">
                <textarea  name="cuerpo_rel" class="form-control"  required="required"><?php if(isset($cuerpo_rel)) { echo $cuerpo_rel;} ?></textarea>
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancel</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  <script src="js/jquery-1.10.2.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html> 