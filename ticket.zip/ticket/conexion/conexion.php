<?php
// Crando la conexion
$con = mysqli_connect('localhost','root', '', 'bdance');
if (!$con) {
    die("Conexión fallida: " . mysqli_error());
}

// Selecciona la DB
$db_select = mysqli_select_db($con, 'bdance');
if (!$db_select) {
    die("Error al selecciona la DB: " . mysqli_error());
}
?>