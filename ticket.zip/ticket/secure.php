<?php 
include('conexion/conexion.php');
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');
$pass = $_POST['pass'];
  
  $seed = str_split('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz');
    $rand = array_rand($seed, 24);
    $convert = array_map(function($n){
        global $seed;
        return $seed[$n];
    },$rand);
 
    $var = implode('',$convert);


if(isset($_POST['Acceder']) && ($pass == "cloudservice"))
{
       header("Location: certificados.php?secure=".$var."");

}


?>

<?php include('assets/head.php'); ?>

<body>

<?php include('assets/menu.php'); ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Acceso</h1>
          </div>
          <form method="POST" action="" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Contraseña</label>
                <div class="col-lg-10">
                  <input type="password" name="pass" class="form-control" id="inputEmail" placeholder="Contraseña" required="required">
                </div>
              </div>
          
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="submit" name="Acceder" value="Acceder" class="btn btn-primary">Acceder</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  <script src="js/jquery-1.10.2.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html> 



