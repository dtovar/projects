<?php 
include('conexion/conexion.php');
mysqli_query($con, "SET NAMES 'utf8'");
header("Content-Type: text/html;charset=utf-8");
?>

  <?php include('assets/head.php') ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Buscar</h1>
          </div>
          <form method="POST" action="busquedafch.php" class="form-horizontal">
            <fieldset>
              <div class='form-group' id='datetimepicker2'>
                    <label for="textArea" class="col-lg-2 control-label">Fecha</label>
                  <div class="col-lg-9">
                    <input type='text' name="fecha_sm" id="datepicker" class="datefield form-control" />
                </div>
                <input type="checkbox" class="col-lg-1" name="opciones[]" value="fecha_sm" />
              </div>
               <div class='form-group' id='datetimepicker2'>
                    <label for="textArea" class="col-lg-2 control-label">Fecha</label>
                  <div class="col-lg-9">
                    <input type='text' name="fecha_r" id="datepicker2" class="datefield form-control" />
                </div>
                <input type="checkbox" class="col-lg-1" name="opciones[]" value="fecha_r" />
              </div>
              <div class="form-group">
                <div class="col-lg-9 col-lg-offset-3">
                  <button type="reset" class="btn btn-default">Cancel</button>
                  <?php $url='busquedafch.php'; ?> 
                  <button type="submit" class="btn btn-primary" onclick="document.location='<?php echo $url; ?>'" value="buscar">Buscar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>