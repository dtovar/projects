<?php
include('conexion/conexion.php');
mysqli_query($con, "SET NAMES 'utf8'");
header("Content-Type: text/html;charset=utf-8");
error_reporting(0);
$consulta="SELECT * FROM contenido ";
$opciones=$_POST['opciones'];
    for ($i=0;$i<=count($opciones)-1;$i++){
      if ($i==0){
        $concatena="WHERE ".$opciones[$i]."='".$_POST[$opciones[$i]]."'";
        $consulta= $consulta.$concatena;
      }  else {
          if($_POST[$opciones[$i]]!=""){
            $concatena=" AND ".$opciones[$i]."='".$_POST[$opciones[$i]]."'";
            $consulta=$consulta.$concatena;
          }
        }
       $resultado=mysqli_query($con, $consulta);
       $cantidad=mysqli_num_rows($resultado);
    }
?>
<html>
<?php include('assets/head.php'); ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Resultados de la búsqueda</h1>
          </div>
          <div>
            <div style="margin-top: 10px; margin-bottom: 10px;" class="col-lg-6">
              <a class="btn btn-primary" href="tickets.php">Añadir Ticket</a>
              <a class="btn btn-primary" style="margin-left: 10px;" href="buscar.php">Búsqueda Avanzada</a>
              <a class="btn btn-primary" style="margin-left: 10px;" href="buscarfch.php">Búsqueda por fecha</a>
            </div>
          </div>
          <table class="display nowrap dataTable dtr-inline" id="myTable" style="width:100%;"> 
          <thead>
            <tr>
              <td class="titulo">Última modificación</td>
              <td class="titulo">Ticket</td>
              <td class="titulo"></td>
            </tr>
            </thead>
            <tbody>
          <?php
          	while ($row = mysqli_fetch_array($resultado)){
          		  //color del estado
                      $estado = $row['estado'];
                      $fecha_ap = $row['fecha_ap'];
                      $fecha_mod = $row['fecha_mod'];
                      if(isset($row['fecha_mod'])) { 
                        $fecha_ap =  $row['fecha_mod'];
                      } else {
                        $fecha_ap = $row['fecha_ap'];
                      }

                      if ($estado == '0'){ $estado = 'Abierto'; } else { $estado = 'Cerrado';}
                      $estado_colors = array('Abierto' => '#ff0000', 'Cerrado' => '#0000ff');
          		 echo "
              <tr style='font-weight:800;color:".$estado_colors[$estado].";'>
                <td>".$row['fecha_sm']." - ".$row['turno']."</td>
                <td>".$row['ticket'].".".$row['cliente'].".".$row['resumen'].".".$row['descripcion']."</td>
                 <td><a class='btn btn-primary' href='ticketsEdit.php?id=".$row['id']."'> <span class='fa fa-pencil'></span></a></td>
              </tr>";
            $i++;
          }
	if (mysqli_num_rows($resultado)==0){
		echo 'No se ha encontrado ningún registro';
	}
?>
         </tbody>
          </table>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
