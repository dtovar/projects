<?php 
include('conexion/conexion.php');
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');

if(isset($_POST['Guardar'])){
if (empty($_POST["nom_cliente"])) {
              echo $nameErr = "El número de ticket no puede estar vacío <br>";
            }else {
               $nom_cliente= $_POST["nom_cliente"];
            }

$res = mysqli_query($con, "INSERT INTO clientes (nom_cliente) VALUES ('$nom_cliente')");
}

?>

<html>
<head>
    <meta charset="utf-8">
    <title>Cliente</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="css/bootstrap.min.css" media="screen">
</head>
<body>
<body>
<?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Añadir Cliente</h1>
          </div>
          <?php 
          if(isset($nameErr)){ echo $nameErr; }
          if($res){
           echo "<p style='color:green;font-size:13px;'> Datos guardados correctamente.</p>";
          }?>
          <form method="POST" action="clientes.php" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Nombre del cliente</label>
                <div class="col-lg-10">
                  <input type="text" name="nom_cliente" class="form-control" id="inputEmail" placeholder="Nombre del cliente" required="required">
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancel</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

  