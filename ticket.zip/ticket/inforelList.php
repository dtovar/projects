<?php 
include('conexion/conexion.php');
$getClientes = mysqli_query($con, "SELECT * FROM inforel");
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');
$rel= $_GET['rel'];

?>

<?php include('assets/head.php'); ?>
<body>
  <?php include('assets/menu.php'); ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Lista de novedades</h1>
          </div>
          <div style="margin-top: 10px; margin-bottom: 10px;" class="col-lg-6">
              <a class="btn btn-primary" href="inforel.php">Añadir</a>
            </div>
          <table class="display nowrap dataTable dtr-inline" id="myTable" style="width:100%;"> 
          <thead>
            <tr>
              <td class="titulo">Título de la novedad</td>
              <td class="titulo">Cuerpo de la Novedad</td>
              <td class="titulo">Opciones</td>
            </tr>
          </thead>
          <tbody>
        <?php
          $result=mysqli_query($con, "SELECT * FROM inforel WHERE tipo_rel='$rel'");
          $i=1;
          while ($row = mysqli_fetch_array($result)){
            echo "
              <tr>
                <td> ".$row['titulo_rel']."</td>
                <td>".$row['cuerpo_rel']."</td>
                <td><a href='inforelEdit.php?id=".$row['id_rel']."'>Editar</a></td>
              </tr>";
            $i++;
          }
        ?>
          </tbody>
          </table>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

