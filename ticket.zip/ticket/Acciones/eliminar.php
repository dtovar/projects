<?php

	include '../conexion/conexion.php';
	$id=$_REQUEST['id'];
	$nom=$_POST['Nombre'];
	$archivo=$_POST['archivo'];
	$query = mysqli_query($con, "SELECT * FROM archivos  WHERE id='$id'");
	$fila = mysqli_fetch_array($query);
	$filex = $fila['archivo'];
	unlink("files/".$filex);
	$query = mysqli_query($con, "DELETE FROM archivos  WHERE id='$id'");
	if($query){
		
		header("Location: ../index.php");
	}
	else{
		echo"Error al introducir la información";
	}
?>