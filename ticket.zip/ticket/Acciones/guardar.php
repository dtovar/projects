<?php
include ('../conexion/conexion.php');
$ruta = "../files/";
opendir($ruta);
$destino = $ruta.$_FILES['archivo']['name'];
copy($_FILES['archivo']['tmp_name'],$destino);
$nombre=$_FILES['archivo']['name'];
$test = $_POST['nombre'];
	mysqli_query($con, "INSERT into archivos (nombre,archivo) values ('$test','$nombre')");
	header("location:../"); 
?>
