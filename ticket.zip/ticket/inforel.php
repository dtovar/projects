<?php 
include('conexion/conexion.php');
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');

if(isset($_POST['Guardar'])){
  $titulo_rel = $_POST['titulo_rel'];
  $cuerpo_rel = $_POST['cuerpo_rel'];
  $tipo_rel = $_POST['tipo_rel'];
  $res = mysqli_query($con, "INSERT INTO inforel (titulo_rel, cuerpo_rel, tipo_rel) VALUES ('$titulo_rel', '$cuerpo_rel', '$tipo_rel')");

}

?>
<?php include('assets/head.php'); ?>
<body>
<?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Añadir Novedad</h1>
          </div>
          <?php 
          if(isset($nameErr)){ echo $nameErr; }
          if($res){
           echo "<p style='color:green;font-size:13px;'> Datos guardados correctamente.</p>";
          }?>
          <form method="POST" action="inforel.php" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Título de novedad</label>
                <div class="col-lg-10">
                  <input type="text" name="titulo_rel" class="form-control" id="inputEmail" placeholder="Nombre del cliente" required="required">
                </div>
              </div>
               <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Tipo de novedad</label>
                <div class="col-lg-10">
                  <select name="tipo_rel" class="form-control" required="required">
                    <option value="" selected="selected">- Selecciona -</option>
                    <option value="Internet">Internet Media</option>
                    <option value="Smart">Smart</option>
                    <option value="General">General</option>

                  </select>
                </div>
              </div>
               <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Cuerpo de novedad</label>
                <div class="col-lg-10">
                  <textarea  name="cuerpo_rel" class="form-control"  required="required"></textarea>
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancel</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  <script src="js/jquery-1.10.2.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html> 