<?php 
include('conexion/conexion.php');
$getClientes = mysqli_query($con, "SELECT * FROM clientes");
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');

if(isset($_POST['Guardar'])){

if (empty($_POST["ticket"])) {
              echo $nameErr = "El número de ticket no puede estar vacío <br>";
            }else {
               $ticket= $_POST["ticket"];
            }

if (empty($_POST["cliente"])) {
               $nameErr = "El cliente no puede estar vacío <br>";
            }else {
               $cliente= $_POST["cliente"];
            }
if (empty($_POST["resumen"])) {
               $nameErr = "El resumen no puede estar vacío <br>";
            }else {
               $resumen= $_POST["resumen"];
            }
if (empty($_POST["descripcion"])) {
               $nameErr = "La descripción no puede estar vacía <br>";
            }else {
               $descripcion= $_POST["descripcion"];
            }
if (empty($_POST["turno"])) {
               $nameErr = "El turno no puede estar vacío <br>";
            }else {
               $turno= $_POST["turno"];
            }

$res = mysqli_query($con, "INSERT INTO contenido (ticket, cliente, resumen, descripcion, turno, fecha_ap) VALUES ('$ticket', '$cliente', '$resumen', '$descripcion', '$turno', '$fecha_ap')");
}

?>
  <?php include('assets/head.php') ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Últimos Tickets</h1>
          </div>
          <table class="table" style="width:100%;" border="1px"> 
          <tbody>
            <tr>
              <td class="titulo"># Ticket</td>
              <td class="titulo">Cliente</td>
              <td class="titulo">Resumen</td>
              <td class="titulo">Descripci&oacute;n</td>
              <td class="titulo">Turno</td>
              <td class="titulo">Fecha</td>
              <td class="titulo">Estatus</td>
              <td class="titulo"></td>
 
            </tr>
        <?php
          $result=mysqli_query($con, "SELECT * FROM contenido WHERE fecha_ap >= DATE(NOW()) - INTERVAL 7 DAY");
          $i=1;
          while ($row = mysqli_fetch_array($result)){

            //color del estado
            $estado = $row['estado'];
            if ($estado == '0'){ $estado = 'Abierto'; } else { $estado = 'Cerrado';}
            $estado_colors = array('Abierto' => '#f95353', 'Cerrado' => '#3CB371');
            //fin del color del estado

            echo "
              <tr>
                <td>".$row['ticket']."</td>
                <td>".$row['cliente']."</td>
                <td>".$row['resumen']."</td>
                <td>".$row['descripcion']."</td>
                <td>".$row['turno']."</td>
                <td>".$row['fecha_ap']."</td>
                <td  style='background-color:".$estado_colors[$estado].";color:#fff;'>".$estado."</td>
                <td><a href='ticketsEdit.php?id=".$row['id']."'>Editar</a></td>
              </tr>";
            $i++;
          }
          if (mysqli_num_rows($result)==0){
          echo("la incidencia no esta guardada en la base de datos");
        }
        ?>
     
          </tbody>
          </table>
        </div>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

