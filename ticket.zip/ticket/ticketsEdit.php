<?php 
include('conexion/conexion.php');
mysqli_query($con, "SET NAMES 'utf8'");
header("Content-Type: text/html;charset=utf-8");
date_default_timezone_set('Europe/Madrid');
$fecha_mod = date('Y-m-d');
$getClientes = mysqli_query($con, "SELECT * FROM clientes");
error_reporting(0);
//get id
if (isset($_GET['id'])) {
$id = $_GET['id'];
$getContenido= mysqli_query($con, "SELECT * FROM contenido WHERE id='$id'");
$fila = mysqli_fetch_array($getContenido);
$ticket = $fila['ticket'];
$cliente = $fila['cliente'];
$resumen = $fila['resumen'];
$descripcion = $fila['descripcion'];
$turno = $fila['turno'];
$estado= $fila['estado'];
}

  $id = $_GET['id'];
//variables
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_sm = date('Y-m-d');
$fecha_mod= date('Y-m-d H:i:s');


if(isset($_POST['Guardar'])){
  $cliente = $_POST['cliente'];
  $resumen = $_POST['resumen'];
  $descripcion = $_POST['descripcion'];
  $turno = $_POST['turno'];
  $estado = $_POST['estado'];
            if (empty($_POST["cliente"])) {
               $nameErr = "El cliente no puede estar vacío. <br>";
            } elseif (empty($_POST["resumen"])) {
               $nameErr = "El resumen no puede estar vacío. <br>";
            } elseif (empty($_POST["descripcion"])) {
               $nameErr = "La descripción no puede estar vacía. <br>";
            }elseif (empty($_POST["turno"])) {
               $nameErr = "El turno no puede estar vacío. <br>";
            } else {

$res = mysqli_query($con, "UPDATE contenido SET resumen='$resumen', descripcion='$descripcion', turno='$turno',fecha_sm='$fecha_sm', fecha_mod='$fecha_mod', estado='$estado' WHERE id='$id'");
}
}

if (isset($_POST['delete'])){
$res = mysqli_query($con, "DELETE FROM contenido WHERE id='$id'");
header('Location: index.php');
}

?>
  <?php include('assets/head.php') ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography"></h1>
          </div>
          <?php 
          if(isset($nameErr)){ echo $nameErr; }
          if(isset($res)){
           echo "<p style='color:green;font-size:13px;'> Datos guardados correctamente.</p>";
          }?>
          <form method="POST" action="" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Número de ticket</label>
                <div class="col-lg-10">
                  <input type="text" name="ticket" class="form-control" id="inputEmail" placeholder="Número de ticket"  value="<?php if(isset($ticket)) { echo $ticket; } ?>" readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-lg-2 control-label">Cliente</label>
                <div class="col-lg-10">
            <?php 
                //echo "<select id='cliente' multiple='' class='form-control' name='cliente[]' >";
              // echo "<option value='' required='required'>- Selecciona -</option>";
              // while ($row = mysqli_fetch_array($getClientes)) { ?>
             <!--  <option value="<?php //echo $row['nom_cliente']; ?>"<?php // if($cliente==$row['nom_cliente']) //echo "selected";?>> <?php //echo $row['nom_cliente']; ?></option> -->
          <?php 
            $clientesList = mysqli_query($con, "SELECT cliente FROM contenido WHERE id='$id'");
            echo "<select id='cliente' multiple='' class='form-control' name='cliente[]' >";
            while ($row2 = mysqli_fetch_array($clientesList)) {
            $selectedValues =  $a;
            $selectOptions = $row['cliente'];
            ?>
             <option selected value="<?php echo $row2['cliente']; ?>"> <?php echo $row2['cliente']; ?></option>
             <?php } ?>
            <?php while ($row = mysqli_fetch_array($getClientes)){ ?>
              <option value="<?php echo $row['nom_cliente']; ?>"> <?php echo $row['nom_cliente']; ?></option>
             <?php  } ?>

  


            </select>
              </div>
              </div>
              <div class="form-group">
                <label for="textArea" class="col-lg-2 control-label">Turno</label>
                <div class="col-lg-10">
                <!-- <input type="text" name="turno" class="form-control" id="inputEmail" value="<?php //if(isset($turno)) { //echo utf8_encode($turno); } ?>" readonly> -->
                  <select name="turno"  class='form-control' required="required">
                    <option value="">- Selecciona -</option>
                    <option value="Mañana" <?php if($turno=='Mañana') echo "selected"; ?> >Mañana</option>
                    <option value="Tarde" <?php if($turno=='Tarde') echo "selected";?> >Tarde</option>
                    <option value="Noche" <?php if($turno=='Noche') echo "selected";?> >Noche</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-lg-2 control-label">Resumen</label>
                <div class="col-lg-10">
                <textarea class='form-control' name="resumen" required="required"><?php if(isset($resumen)) { echo $resumen; } ?></textarea>                
              </div>
              <div class="form-group">
                <label class="col-lg-2 control-label">Descripción</label>
                <div class="col-lg-10">
                  <textarea class='form-control' name="descripcion" required="required"><?php if(isset($descripcion)) { echo $descripcion; } ?></textarea>
                </div>
              </div>
              <div class="form-group">
                <label for="textArea" class="col-lg-2 control-label">Estado</label>
                <div class="col-lg-10">
                  <select name="estado"  class='form-control'>
                    <option value="0" <?php if($estado=='0') echo "selected";?>>Abierto</option>
                    <option value="1" <?php if($estado=='1') echo "selected";?>>Cerrado</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancelar</button>
                  <button type="submit" name="delete" value="delete" class="btn btn-danger" onclick="return confirm('¿Estás seguro que deseas eliminar este registro?');">Eliminar</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary" onclick="return confirm('¿Todos los cambios son correctos?');">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

  