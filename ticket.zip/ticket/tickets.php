<?php 
include('conexion/conexion.php');
mysqli_query($con, "SET NAMES 'utf8'");
header("Content-Type: text/html;charset=utf-8");
$getClientes = mysqli_query($con, "SELECT * FROM clientes");

error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_sm = date('Y-m-d');
$fecha_ap = date('Y-m-d H:i:s');
$fecha_mod = date('Y-m-d H:i:s');


if((isset($_POST['Guardar'])) && (empty($_POST['noticket']))) {
  $code = "INC";
  $ticket = $_POST['ticket'];
  $cliente = $_POST['cliente'];
  $resumen = $_POST['resumen'];
  $descripcion = $_POST['descripcion'];
  $turno = $_POST['turno'];

//sanitize and verify the input here. Escape properly and what not

  $getTicket = mysqli_query($con, "SELECT * FROM contenido WHERE ticket='$code$ticket'");
  $checkTicket = mysqli_num_rows($getTicket);

            if (empty($_POST["ticket"])){
              echo $nameErr = "El número de ticket no puede estar vacío. <br>";
            } elseif (($checkTicket)>=1) {
             echo $nameErr = "El número de ticket ya existe. <br>";
            } elseif ((strlen($ticket)<6) || (strlen($ticket)>6)) {
              $nameErr = "El número de ticket debe tener 6 dígitos. <br>";
            } elseif (empty($_POST["cliente"])) {
               $nameErr = "El cliente no puede estar vacío. <br>";
            } elseif (empty($_POST["resumen"])) {
               $nameErr = "El resumen no puede estar vacío. <br>";
            } elseif (empty($_POST["descripcion"])) {
               $nameErr = "La descripción no puede estar vacía. <br>";
            } elseif (empty($_POST["turno"])) {
               $nameErr = "El turno no puede estar vacío. <br>";
            } else {

            for($i = 0; $i < count($cliente); $i++){
            $res = mysqli_query($con, "INSERT INTO contenido (ticket, cliente, resumen, descripcion, turno, fecha_sm, fecha_ap, fecha_mod) VALUES ('$code$ticket', '$cliente[$i]', '$resumen', '$descripcion', '$turno', '$fecha_sm', '$fecha_ap', '$fecha_mod')");
            }
            
            
}
} elseif (isset($_POST['Guardar']) && (isset($_POST['noticket']))) {
  $cliente = $_POST['cliente'];
  $resumen = $_POST['resumen'];
  $descripcion = $_POST['descripcion'];
  $turno = $_POST['turno'];


            if (empty($_POST["cliente"])) {
               $nameErr = "El cliente no puede estar vacío. <br>";
            }  elseif (empty($_POST["resumen"])) {
               $nameErr = "El resumen no puede estar vacío. <br>";
            } elseif (empty($_POST["descripcion"])) {
               $nameErr = "La descripción no puede estar vacía. <br>";
            } elseif (empty($_POST["turno"])) {
               $nameErr = "El turno no puede estar vacío. <br>";
            } else {

            for($i = 0; $i < count($cliente); $i++){
            $res = mysqli_query($con, "INSERT INTO contenido (ticket, cliente, resumen, descripcion, turno, fecha_sm, fecha_ap, fecha_mod) VALUES ('INC000000', '$cliente[$i]', '$resumen', '$descripcion', '$turno', '$fecha_sm', '$fecha_ap', '$fecha_mod')");
            }
}
}

?>
  <?php include('assets/head.php') ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Tickets</h1>
          </div>
          <?php echo $res;
          if(isset($nameErr)){ echo $nameErr; }
          if($res){
           echo "<p style='color:green;font-size:13px;'> Datos guardados correctamente.</p>";
          }

          ?>

          <form method="POST" action="tickets.php" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Número de ticket</label>
                 <div class="col-lg-9">
                  <input type="text" name="ticket" class="form-control" id="ticket" placeholder="Número de ticket" >
                </div>
                <input type="checkbox" id="noticket" class="col-lg-1" name="noticket" value="noticket" onclick="document.getElementById('ticket').disabled=this.checked;"
 /></td>
              </div>
              <div class="form-group">
                <label class="col-lg-2 control-label">Cliente</label>
                <div class="col-lg-10">
            <?php 
                 echo "<select multiple='' id='cliente' class='form-control' name='cliente[]'>";
                 echo "<option value='' selected='selected' required='required'>- Selecciona -</option>";
                 while ($row = mysqli_fetch_array($getClientes)) {
                echo "<option value='".$row['nom_cliente']."'>".$row['nom_cliente']."</option>";
              }
                 echo "</select><br>";
            ?>
              </div>
              <div class="form-group">
                <label for="textArea" class="col-lg-2 control-label">Turno</label>
                <div class="col-lg-10">
                  <select name="turno"  class='form-control' required="required">
                    <option value="" selected="selected">- Selecciona -</option>
                    <option value="Mañana">Mañana</option>
                    <option value="Tarde">Tarde</option>
                    <option value="Noche">Noche</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="col-lg-2 control-label">Resumen</label>
                <div class="col-lg-10">
                <textarea class='form-control' name="resumen" required="required"></textarea>                
              </div>
              <div class="form-group">
                <label class="col-lg-2 control-label">Descripción</label>
                <div class="col-lg-10">
                  <textarea class='form-control' name="descripcion" required="required"></textarea>
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancel</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

  