<?php 
include('conexion/conexion.php');
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');

if(isset($_POST['Guardar'])){
  $titulo = $_POST['titulo'];
  $tipo = $_POST['tipotulo'];
  $dtr = $_POST['dtr'];
  $enlace = $_POST['enlace'];
  $res = mysqli_query($con, "INSERT INTO abm (titulo, dtr, enlace, tipo) VALUES ('$titulo', '$dtr', '$enlace', '$tipo')");
}

?>
<?php include('assets/head.php'); ?>
<body>
<?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Añadir documentación</h1>
          </div>
          <?php 
          if(isset($nameErr)){ echo $nameErr; }
          if($res){
           echo "<p style='color:green;font-size:13px;'> Datos guardados correctamente.</p>";
          }?>
          <form method="POST" action="" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Título de documentación</label>
                <div class="col-lg-10">
                  <input type="text" name="titulo" class="form-control" id="inputEmail" placeholder="Título" required="required">
                </div>
              </div>
               <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">DTR</label>
                <div class="col-lg-10">
                <input type="text" name="dtr" class="form-control" id="inputEmail" placeholder="DTR" required="required">
                </div>
              </div>
               <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Enlace</label>
                <div class="col-lg-10">
                <input type="text" name="enlace" class="form-control" id="inputEmail" placeholder="Enlace" required="required">
                </div>
              </div>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Tipo</label>
                <div class="col-lg-10">
                  <select name="tipo" class="form-control" required="required">
                    <option value="" selected="selected">- Selecciona -</option>
                    <option value="Internet">Internet Media</option>
                    <option value="Smart">Smart</option>
                    <option value="General">General</option>

                  </select>
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancelar</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
  <script src="js/jquery-1.10.2.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html> 