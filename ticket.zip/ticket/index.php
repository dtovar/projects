<?php 
include('conexion/conexion.php');
mysqli_query($con, "SET NAMES 'utf8'");
header("Content-Type: text/html;charset=utf-8");
$getClientes = mysqli_query($con, "SELECT * FROM clientes");
error_reporting(0);
function make_links($text, $class='', $target='_blank'){
    return preg_replace('!((http\:\/\/|ftp\:\/\/|https\:\/\/)|www\.)([-a-zA-Zа-яА-Я0-9\~\!\@\#\$\%\^\&\*\(\)_\-\=\+\\\/\?\.\:\;\'\,]*)?!ism', 
    '<a class="'.$class.'" href="//$3" target="'.$target.'">$1$3</a>', 
    $text);
}
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');

if(isset($_POST['Guardar'])){
$titulo_novedad = $_POST['titulo_novedad'];
$cuerpo_novedad = $_POST['cuerpo_novedad'];
$res = mysqli_query($con, "INSERT INTO novedad (titulo_novedad, cuerpo_novedad) VALUES ('$titulo_novedad', '$cuerpo_novedad')");
}

if(isset($_POST['deleteItem']))
{
  // here comes your delete query: use $_POST['deleteItem'] as your id
  $delete = $_POST['deleteItem'];
  $sql2 = mysqli_query($con, "UPDATE novedad SET show_novedad='1' WHERE id_novedad='$delete'"); 
}

function nov_limit($x, $length)
{
  if(strlen($x)<=$length)
  {
    echo $x;
  }
  else
  {
    $y=substr($x,0,$length) . '...';
    echo $y;
  }
}

?>
<?php include('assets/head.php') ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
         <div class="page-header">
              <h3 id="typography">Noticias</h3>
          </div>
          <div>
      
          <?php 
          //recibo los anuncios de la base de datos
          $ssql= "SELECT * FROM novedad WHERE show_novedad='0' order by id_novedad desc limit 6";
          //conecto con la base de dato
          $rs = mysqli_query($con, $ssql);
          while ($rw = mysqli_fetch_array($rs)){
            //para cada novedad
            $novedad = $rw['cuerpo_novedad'];
            echo "<div id='style-4' class='col-lg-2 note' style='background-color:#f6f6f4;margin-left:2px; margin-right:2px; text-align:justify;overflow: auto; min-height: 160px; max-height: 160px;overflow: auto; max-height: 160px;'>";
            echo "<div style='margin-top:5px;float: right;'><form action='#' method='POST'>";
            echo "<a data-toggle='modal' data-target='#view-modal' data-id='".$rw['id_novedad']."' id='getNov' style='margin-top:5px; color:blue; font-size:15px;' href='#ver'><i class='fa fa-eye'></i></a><button type='submit' id='del' name='deleteItem' value='".$rw['id_novedad']."' class=''><i class='fa fa-trash' style='color:red; font-size:15px;'></i></button></form></div>";
            echo "<p style='font-weight:600;margin-top:3px;'>".nov_limit($rw["titulo_novedad"],15)."</p>";
            echo "<p>".nov_limit($rw["cuerpo_novedad"], 70)."</p>";
            echo "</div>";
            
          }

        ?>
        </div>
        <br>
        </div>
        <div style="margin-top: 10px; margin-bottom: 10px;">
              <a data-toggle='modal' data-target='#view-form' class="btn btn-primary" href="#">Añadir novedad</a>
          </div>
        <div class="row">
          <div class="page-header">
              <h3 id="typography">Novedades</h3>
          </div>
          <div>
            <div style="margin-top: 10px; margin-bottom: 10px;" class="col-lg-6">
              <a class="btn btn-primary" href="tickets.php">Añadir Ticket</a>
              <a class="btn btn-primary" style="margin-left: 10px;" href="buscar.php">Búsqueda avanzada</a>
              <a class="btn btn-primary" style="margin-left: 10px;" href="buscarfch.php">Búsqueda por fecha</a>
            </div>
          </div>
          <table class="table" id="myTable" style="width:100%;"> 
          <thead>            
          <tr>
            <td class="titulo">Última modificación</td>
            <td class="titulo">Ticket</td>
            <td class="titulo"></td>
          </tr>
            </thead>
          <tbody>
        <?php
          $result=mysqli_query($con, "SELECT * FROM contenido WHERE fecha_ap >= DATE(NOW()) - INTERVAL 7 DAY ORDER BY fecha_mod DESC");
          $i=1;
          while ($row = mysqli_fetch_array($result)) {
            //color del estado
            $estado = $row['estado'];
            $fecha_ap = $row['fecha_ap'];
            $fecha_mod = $row['fecha_mod'];
            if ($estado == '0'){ $estado = 'Abierto'; } else { $estado = 'Cerrado';}
            $estado_colors = array('Abierto' => '#ff0000', 'Cerrado' => '#0000ff');
            echo "
              <tr style='color:".$estado_colors[$estado].";'>
                <td>".$row['fecha_sm']." - ".$row['turno']."</td>
                <td><b>".make_links($row['ticket'].".".$row['cliente'].".".$row['resumen']."</b>.".$row['descripcion'])."</td>
                <td><a class='btn btn-primary' href='ticketsEdit.php?id=".$row['id']."'> <span class='fa fa-pencil'></span></a></td>
              </tr>";
            $i++;
          }         
        if (mysqli_num_rows($result)==0){
        echo("la incidencia no esta guardada en la base de datos");
        }
        ?>
          </tbody>
          </table>
        </div>
      </div>
    </div>

    <div id="view-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
   <div class="modal-dialog"> 
      <div class="modal-content"> 
                  
         <div class="modal-header"> 
             <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> 
             <h4 class="modal-title">
             <i class="fa fa-info"></i> Detalle de novedad
             </h4> 
         </div> 
         
         <div class="modal-body"> 
                       
             <div id="modal-loader" style="display: none; text-align: center;">
             </div>
                       
             <div id="dynamic-content"> <!-- mysql data will load in table -->
                                        
                 <div class="row"> 
                     <div class="col-md-12"> 
                        
                     <div class="table-responsive">
                             
                     <table class="table table-striped table-bordered">
                     <tr>
                     <th>Título de novedad</th>
                     <td id="titulo_novedad"></td>
                     </tr>
                                     
                     <tr>
                     <th>Descripcióm</th>
                     <td id="cuerpo_novedad"></td>
                     </tr>
                                         
                     </table>
                                
                     </div>
                                       
                   </div> 
              </div>
                       
             </div> 
                             
         </div> 
           
       <div class="modal-footer"> 
            <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>  
       </div>  
              
      </div> 
   </div>
</div>



<div id="view-form" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
   <div class="modal-dialog"> 
      <div class="modal-content"> 
                  
         <div class="modal-header"> 
             <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> 
             <h4 class="modal-title">
             <i class="fa fa-plus"></i> Añadir de novedad
             </h4> 
         </div> 
         
         <div class="modal-body"> 
                       
             <div id="modal-loader" style="display: none; text-align: center;">
             </div>
                       
             <div id="dynamic-content"> <!-- mysql data will load in table -->
                                        
                 <div class="row"> 
                     <div class="col-md-12"> 
                      
                      <form method="POST" action="" class="form-horizontal">
                      <fieldset>
                        <div class="form-group">
                          <label for="inputEmail" class="col-lg-2 control-label">Título de la novedad</label>
                          <div class="col-lg-10">
                            <input type="text" name="titulo_novedad" class="form-control" id="inputEmail" placeholder="Título de la novedad"  required="required">
                          </div>
                        </div>
                         <div class="form-group">
                          <label for="inputEmail" class="col-lg-2 control-label">Cuerpo de la novedad</label>
                          <div class="col-lg-10">
                            <textarea type="text" name="cuerpo_novedad" class="form-control" id="inputEmail" placeholder="Cuerpo de la novedad"  required="required"></textarea>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="col-lg-10 col-lg-offset-2">
                            <button type="button" data-dismiss="modal" class="btn btn-default">Cancelar</button>
                            <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                          </div>
                        </div>
                      </fieldset>
                    </form>
                                
                     </div>
                                       
                   </div> 
              </div>
                       
             </div> 
                             
         </div>  
              
      </div> 
   </div>
</div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

