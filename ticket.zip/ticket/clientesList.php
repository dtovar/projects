<?php 
include('conexion/conexion.php');
$getClientes = mysqli_query($con, "SELECT * FROM clientes");
error_reporting(0);
//obtener hora/fecha actual
date_default_timezone_set('Europe/Madrid');
$fecha_ap = date('Y-m-d H:i:s');

if(isset($_POST['Guardar'])){

if (empty($_POST["ticket"])) {
              echo $nameErr = "El número de ticket no puede estar vacío <br>";
            }else {
               $ticket= $_POST["ticket"];
            }

if (empty($_POST["cliente"])) {
               $nameErr = "El cliente no puede estar vacío <br>";
            }else {
               $cliente= $_POST["cliente"];
            }
if (empty($_POST["resumen"])) {
               $nameErr = "El resumen no puede estar vacío <br>";
            }else {
               $resumen= $_POST["resumen"];
            }
if (empty($_POST["descripcion"])) {
               $nameErr = "La descripción no puede estar vacía <br>";
            }else {
               $descripcion= $_POST["descripcion"];
            }
if (empty($_POST["turno"])) {
               $nameErr = "El turno no puede estar vacío <br>";
            }else {
               $turno= $_POST["turno"];
            }

$res = mysqli_query($con, "INSERT INTO contenido (ticket, cliente, resumen, descripcion, turno, fecha_ap) VALUES ('$ticket', '$cliente', '$resumen', '$descripcion', '$turno', '$fecha_ap')");
}

?>

<?php include('assets/head.php') ?>
<body>
  <?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Lista de Clientes</h1>
          </div>
          <table class="display nowrap dataTable dtr-inline" id="myTable" style="width:100%;"> 
          <thead>
            <tr>
              <td class="titulo"># Cliente</td>
              <td class="titulo">Nombre de cliente Cliente</td>
              <td class="titulo">Opciones</td>
            </tr>
          </thead>
          <tbody>
        <?php
          $result=mysqli_query($con, "SELECT * FROM clientes");
          $i=1;
          while ($row = mysqli_fetch_array($result)){
            echo "
              <tr>
                <td># ".$row['id']."</td>
                <td>".$row['nom_cliente']."</td>
                <td><a href='clientesEdit.php?id=".$row['id']."'>Editar</a></td>
              </tr>";
            $i++;
          }
        ?>
          </tbody>
          </table>
        </div>
      </div>
    </div>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

