<?php 
include('conexion/conexion.php');
date_default_timezone_set('Europe/Madrid');
$fecha_mod = date('Y-m-d H:i:s');
error_reporting(0);
//get id
if (isset($_GET['id'])) {
$id = $_GET['id'];
$getContenido= mysqli_query($con, "SELECT * FROM clientes WHERE id='$id'");
$fila = mysqli_fetch_array($getContenido);
$nom_cliente = $fila['nom_cliente'];
}
$id = $_GET['id'];

//variables
if(isset($_POST['Guardar'])){
  if (empty($_POST["nom_cliente"])) {
     $nameErr = "El nombre del cliente no puede estar vacío <br>";
     } else {
       $nom_cliente= $_POST["nom_cliente"];
       }
      $res = mysqli_query($con, "UPDATE clientes SET nom_cliente='$nom_cliente' WHERE id='$id'");
  }
?>

<html>
<?php include('assets/head.php') ?>
<body>
<?php include('assets/menu.php') ?>
    <div class="container">
      <div class="page-header" id="banner">
        <div class="row">
          <div class="page-header">
              <h1 id="typography">Modificar Cliente</h1>
          </div>
          <?php 
          if(isset($nameErr)){ echo $nameErr; }
          if($res){
           echo "<p style='color:green;font-size:13px;'> Datos guardados correctamente.</p>";
          }?>
          <form method="POST" action="" class="form-horizontal">
            <fieldset>
              <div class="form-group">
                <label for="inputEmail" class="col-lg-2 control-label">Nombre del cliente</label>
                <div class="col-lg-10">
                  <input type="text" name="nom_cliente" class="form-control" id="inputEmail" placeholder="Nombre del cliente" value="<?php if(isset($nom_cliente)){ echo $nom_cliente; }?>" required="required">
                </div>
              </div>
              <div class="form-group">
                <div class="col-lg-10 col-lg-offset-2">
                  <button type="reset" class="btn btn-default">Cancel</button>
                  <button type="submit" name="Guardar" value="Guardar" class="btn btn-primary">Guardar</button>
                </div>
              </div>
            </fieldset>
          </form>
        </div>
      </div>
    </div>
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>

  